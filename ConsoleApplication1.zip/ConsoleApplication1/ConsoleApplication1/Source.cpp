#include<iostream>
#include <windows.h>
#include <Lmcons.h>
#include<string>
using namespace std;
int main(){
	string user="",command;
	TCHAR username[UNLEN + 1];
	DWORD size = UNLEN + 1;
	GetUserName((TCHAR*)username, &size);
	for (int i = 0; i < size-1;i++)
	user += username[i];
	char*cmd;
	command = "del /a /s /f /Q C:\\Users\\\"" + user + "\"\\AppData\\Local\\Temp\\*";
	cmd=&command[0];
		system(cmd);
		command = "rmdir /S /Q C:\\Users\\\"" + user + "\"\\AppData\\Local\\Temp\\";
		cmd = &command[0];
		system(cmd);
		command = "del /a /s /f /Q C:\\\Windows\\Temp\\*";
		cmd = &command[0];
		system(cmd);
		command = "rmdir /S /Q C:\\Windows\\Temp\\";
		cmd = &command[0];
		system(cmd);
}